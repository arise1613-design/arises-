SHADOW SYSTEM - Android Studio project
This package contains the Android WebView app source and its offline-first tracker.
To build an APK:
1. Install Android Studio on a computer.
2. Open this ShadowSystem folder as an existing project.
3. Allow Gradle sync and Android SDK installation.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK at app/build/outputs/apk/debug/app-debug.apk.
The tracker saves XP, reports and quest completion locally on the device.
No account or cloud sync is included.
